export const runtime = "nodejs";

import { NextResponse } from "next/server";
import nodemailer from "nodemailer";

// from: src/app/api/mfa/email/request/route.js  →  src/lib/...
import { adminAuth, adminDb, FieldValue } from "../../../../../lib/firebaseAdmin";
import { generateOTP } from "../../../../../lib/otp";


export async function POST(req) {
  try {
    // 1) Autorizare – așteptăm Authorization: Bearer <idToken>
    const authHeader = req.headers.get("authorization") || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
    if (!idToken) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

    const decoded = await adminAuth.verifyIdToken(idToken);
    const uid = decoded.uid;
    const email = decoded.email;
    if (!email) return NextResponse.json({ error: "no_email" }, { status: 400 });

    // 2) Cooldown rapid pentru resend (30s) + max 3 resend (opțional)
    const docRef = adminDb.collection("mfa_codes").doc(uid);
    const snap = await docRef.get();
    const now = Date.now();

    if (snap.exists) {
      const d = snap.data();
      if (d.lastSentAt && now - Number(d.lastSentAt) < 30 * 1000) {
        const retryAfter = 30 - Math.floor((now - Number(d.lastSentAt)) / 1000);
        return NextResponse.json({ error: "cooldown", retryAfter }, { status: 429 });
      }
      if ((d.resendCount || 0) >= 3) {
        return NextResponse.json({ error: "too_many_resends" }, { status: 429 });
      }
    }

    // 3) Generează OTP (6 cifre), expiră în 10 minute
    const { code, salt, hash } = generateOTP();
    const expiresAt = now + 10 * 60 * 1000;

    // 4) Salvează în Firestore (hash + salt + expirare)
    await docRef.set(
      {
        uid,
        email,
        hash,
        salt,
        expiresAt,
        attemptCount: 0,
        resendCount: FieldValue.increment(1),
        lastSentAt: now,
        createdAt: FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    // 5) Trimite e-mail prin SMTP (Brevo)
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: String(process.env.SMTP_SECURE || "false").toLowerCase() === "true",
      auth: process.env.SMTP_USER
        ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
        : undefined,
    });

    const from = process.env.MFA_EMAIL_FROM || "AceIBMath <noreply@aceibmath.com>";

    await transporter.sendMail({
      from,
      to: email,
      replyTo: from, // dacă nu vrei răspunsuri, păstrează tot noreply@
      subject: "Your verification code",
      text: `Your code is ${code}. It expires in 10 minutes.`,
      html: `<p>Your code is <b style="font-size:20px;letter-spacing:2px">${code}</b>. It expires in 10 minutes.</p>`,
    });

    return NextResponse.json({ ok: true, expiresAt });
  } catch (err) {
    console.error("/api/mfa/email/request error", err);
    return NextResponse.json({ error: "internal" }, { status: 500 });
  }
}
